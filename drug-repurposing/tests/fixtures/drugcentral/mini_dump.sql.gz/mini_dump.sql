-- dump
COPY public.approval (id, struct_id, approval, type, applicant, orphan) FROM stdin;
1	10	1950-01-01	FDA	X	f
2	10	1990-05-05	EMA	Y	f
3	11	1999-02-02	EMA	Z	f
4	12	2005-03-03	FDA	W	f
5	12	1998-03-03	FDA	W2	f
6	13	\N	FDA	V	f
\.

COPY public.identifier (id, identifier, id_type, struct_id, parent_match) FROM stdin;
1	DB00945	DRUGBANK_ID	10	\N
2	D00001	KEGG_DRUG	10	\N
3	DB01050	DRUGBANK_ID	11	\N
4	DB00316	DRUGBANK_ID	12	\N
5	DB07777	DRUGBANK_ID	13	\N
\.
